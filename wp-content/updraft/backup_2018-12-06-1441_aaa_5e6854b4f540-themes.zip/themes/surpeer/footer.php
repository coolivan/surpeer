
		<div class="footer">
			<div class="wrap">
				<div class="container">
					<div class="row">

						<div class="col-md-4">
							<div class="footer-title">
								<h3>Location</h3>
							</div>
							<div class="footer-info">
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis dignissim erat ut laoreet pharetra....</p>
							</div>
							<div class="footer-address">
								<ul>
									<li><i class="fa fa-home" aria-hidden="true"></i> No. 96, Jecica City, NJ 07305, New York, USA</li>
									<li><i class="fa fa-phone" aria-hidden="true"></i> (+1)866-540-3229</li>
									<li><i class="fa fa-envelope-o" aria-hidden="true"></i> roadthemes@example.com</li>
								</ul>
							</div>
						</div>
						<div class="col-md-4 col-md-offset-1">
							<div class="footer-title">
								<h3>Surpeer</h3>
							</div>
							<ul>
								<li>
									<a href="">HOME</a>
								</li>
								<li>
									<a href="">PRODUCTS</a>
								</li>
								<li>
									<a href="">NEWS</a>
								</li>
								<li>
									<a href="">ABOUT US</a>
								</li>
								<li>
									<a href="">COUNTACT US</a>
								</li>
							</ul>
						</div>

						<!--<div class="col-md-3">
							<div class="footer-title">
								<h3>Shop Location</h3>								
							</div>
						</div>-->

						<div class="col-md-3">
							
					
							<?php echo wpm_form(1); ?>
						
							<div class="wpb_wrapper footer-title">
								<h3>Stay Connected</h3>
							</div>
							<ul class="social-icons">
								<li>
									<a class="facebook social-icon" href="https://www.facebook.com" title="Facebook" target="_blank"><i class="fa fa-facebook"></i></a>
								</li>
								<li>
									<a class="twitter social-icon" href="https://twitter.com" title="Twitter" target="_blank"><i class="fa fa-twitter"></i></a>
								</li>
								<li>
									<a class="instagram social-icon" href="https://www.instagram.com" title="Instagram" target="_blank"><i class="fa fa-instagram"></i></a>
								</li>
								<li>
									<a class="linkedin social-icon" href="https://www.linkedin.com" title="Linkedin" target="_blank"><i class="fa fa-linkedin"></i></a>
								</li>
								<li>
									<a class="rss social-icon" href="https://www.rss.com" title="Rss" target="_blank"><i class="fa fa-rss"></i></a>
								</li>
							</ul>
						</div>

					</div>

				</div>
			</div>
		
			<div class="copyright">
				<div class="container">
					Copyright © Surpeer. All Rights Reserved.
				</div>
			</div>
			<div id="back-top" class="show"><i class="fa fa-angle-up fa-2x"></i></div>
		</div>

		<script src="http://cdn.bootcss.com/jquery/1.11.0/jquery.min.js" type="text/javascript"></script>
		<script>
			window.jQuery || document.write('<script src="/wp-content/themes/surpeer/js/jquery.min.js"><\/script>')
		</script>
		<script src="/wp-content/themes/surpeer/js/bootstrap.min.js" type="text/javascript" charset="utf-8"></script>
		<script src="/wp-content/themes/surpeer/js/owl.carousel.min.js" type="text/javascript" charset="utf-8"></script>
		<script src="/wp-content/themes/surpeer/js/main.js" type="text/javascript" charset="utf-8"></script>
		
		
		
	</body>

</html>
