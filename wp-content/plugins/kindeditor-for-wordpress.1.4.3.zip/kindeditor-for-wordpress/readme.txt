﻿=== Plugin Name ===
Contributors: panxianhai
Donate link: http://weibo.com/hevinpan
Tags: editor, syntax highlighting
Requires at least: 3.0
Tested up to: 4.1.1
Stable tag: 1.4.3

Kindeditor for wordpress

== Description ==

Because most users of this plug-in are Chinese people,following I use Chinese.

kindeditor是一个简单高效，易于使用的编辑器，自带代码高亮。

== Installation ==

1. 上传kindeditor-for-wordpress文件夹到`/wp-content/plugins/`目录
2. 激活插件即可使用，注意应关闭其他的编辑器插件

== Frequently Asked Questions ==

= 点击查看更多按钮的时候为什么没有内容？ =

目前这个功能还没有确定一个好的解决方案，所以只是在代码视图插入了<!--more-->，可视化界面没有任何输出。

= 如何开启代码高亮？ =

配置项中开启代码高亮。

== Screenshots ==

1. 编辑器视图
2. 字数统计
3. 内容引用
4. 插入程序代码

== Changelog ==

= 1.4.3 =
* fix a bug in wp 4.1.1

= 1.4.2 =
* 在1.3.7版本上优化了若干项，重新上传了，因为之前的代码高亮依赖性比较大
* 不会增加水印功能了，使用水印插件的朋友请使用wordpress的自带上传

= 1.4.1 =
* 修正了按钮无法显示的问题

＝ 1.4 ＝
* 精简功能(去掉了图片上传等功能)
* 更改filterMode为false
* 精简代码

= 1.3.7 =
* 更新kindeditor到4.1.10

= 1.3.6 =
* 更新kindeditor到4.1.7
* 增加template功能

= 1.3.4 =
* 更新kindeditor到4.1.6
* 调整部分样式

= 1.3.3 =
* 更新kindeditor到4.1.5

= 1.3.2 =
* 更新kindeditor内核到4.1.4
* 增加单图片上传和多图上传

= 1.3.1 =
* 更新kindeditor内核到4.1.3

= 1.3 =
* 更新kindeditor内核到4.1.2
* 增加代码高亮样式可选择

= 1.2.1 =
* 增加了图片，视频，flash的连接插入
* 取消了1.2版本中增加的新版提示功能

= 1.2 =
* 更新kindeditor内核到4.1
* 为未上传到官方插件目录之前添加了插件更新提示

= 1.1.4 =
* 为代码高亮相关文件自动载入设置了是否开启的选项
* 前台无需修改，即可实现代码高亮，相关文件已经自动载入
* 更新kindeditor内核到4.0.5

= 1.1.3 =
* 修正了wordpress 3.3显示原来编辑器的问题
* 更新kindeditor内核到4.0.4

= 1.1.2 =
* 更新kindeditor内核到4.0.2

= 1.1.1 =
* 修改一些小错误

= 1.1.0 =
* 修正了IE下插入more标签需要在前面加入字符的问题
* 更新kindeditor内核到4.0.1

= 1.0.0=
* 发布kindeditor-for-wordpress插件

== Upgrade Notice ==
无升级信息
