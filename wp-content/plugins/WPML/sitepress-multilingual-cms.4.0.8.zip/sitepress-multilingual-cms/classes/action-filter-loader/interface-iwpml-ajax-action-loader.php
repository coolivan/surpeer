<?php
/**
 * @author OnTheGo Systems
 */
interface IWPML_AJAX_Action_Loader extends IWPML_Action_Loader_Factory {

}
