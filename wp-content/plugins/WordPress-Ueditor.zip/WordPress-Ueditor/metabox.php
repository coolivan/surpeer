<?php      
//自定义面板类的实例化      
/**********title*************/     
$options = array();      
//page参数为在页面和文章中都添加面板 ，可以添加自定义文章类型   
//context参数为面板在后台的位置，比如side则显示在侧栏    
//字段调用，比如调用上面配置文件中的文本框字段：$ashu_eitor = get_post_meta($post->ID, "ashu_text", true); //ashu_text为配置文件中文本框的id  

  
$boxinfo = array('title' => 'meta box', 'id'=>'ashubox', 'page'=>array('page','post'), 'context'=>'normal', 'priority'=>'low', 'callback'=>'');      
     
$options[] = array( "name" => "标题",      
            "type" => "title");      
                  
$options[] = array(      
            "name" => "文本框",      
            "desc" => "",      
            "id" => "ashu_text",      
            "size"=>"40",      
            "std" => "",      
            "type" => "text"     
            );      
                  
$options[] = array(      
            "name" => "文本域",      
            "desc" => "",      
            "id" => "ashu_textarea",      
            "std" => "",      
            "type" => "textarea"     
            );      
                  
$options[] = array(      
            "name" => "图片上传",      
            "desc" => "",      
            "id" => "ashu_upimg",      
            "std" => "",      
            "button_label"=>'上传图片',      
            "type" => "media"     
            );      
                  
$options[] = array(      
            "name" => "单选框",      
            "desc" => "",      
            "id" => "ashu_radio",      
            "std" => 1,      
            "buttons" => array('Yes','No'),   
            "type" => "radio"     
            );      
                  
$options[] = array(      
            "name" => "复选框",      
            "desc" => "喜欢吃啥？",      
            "id" => "ashu_checkbox",      
            "buttons" => array('苹果','香蕉','西瓜','芒果'),   
            "type" => "checkbox"     
            );      
     
$options[] = array(      
            "name" => "下拉选择",      
            "desc" => "",      
            "id" => "ashu_dropdown",      
            "subtype"=> array(      
                '1'=>'1',      
                '2'=>'2',      
                '3'=>'3'      
            ),      
            "type" => "dropdown"     
            );      
                  
$options[] = array(      
            "name" => "选择分类",      
            "desc" => "",      
            "id" => "ashu_cat",      
            "subtype"=> "cat",      
            "type" => "dropdown"     
            );      
                  
$options[] = array(      
            "name" => "选择页面",      
            "desc" => "",      
            "id" => "ashu_page",      
            "subtype"=> "page",      
            "type" => "dropdown"     
            );      
                  
$options[] = array(      
            "name" => "选择菜单",      
            "desc" => "",      
            "id" => "ashu_menu",      
            "subtype"=> "menu",      
            "type" => "dropdown"     
            );      
                  
$options[] = array(      
            "name" => "选择侧边栏",      
            "desc" => "",      
            "id" => "ashu_sidebar",      
            "subtype"=> "sidebar",      
            "type" => "dropdown"     
            );   
  
                  
$options[] = array(      
            "name" => "编辑器",      
            "desc" => "",      
            "id" => "ashu_tinymce",      
            "std" => "",   
            "type" => "tinymce"     
            );                 
                  
$new_box = new ashu_meta_box($options, $boxinfo);      
?>  